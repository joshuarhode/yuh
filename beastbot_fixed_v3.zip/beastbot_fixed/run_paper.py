from beastbot.runner_paper import run

if __name__ == "__main__":
    run(30)
